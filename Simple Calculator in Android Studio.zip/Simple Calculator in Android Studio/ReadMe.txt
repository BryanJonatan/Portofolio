to try the calculator, it required Android Studio so make sure to have one

Code Location
app -> src -> main -> java -> ide -> ac -> binus -> Project Calculator -> Main Activity