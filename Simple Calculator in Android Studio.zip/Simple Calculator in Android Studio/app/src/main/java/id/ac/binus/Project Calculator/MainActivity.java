package id.ac.binus.session3;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import id.ac.binus.session3.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText edtNumber;
Button btnSatu, btnDua,btnTiga, btnEmpat,btnLima, btnEnam,btnTujuh,btnDelapan,btnSembilan,btnNol,btnPlus,btnMinus,btnDiv,btnTimes,btnEqual;
    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;


        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            binding = ActivityMainBinding.inflate(getLayoutInflater());
            setContentView(R.layout.activity_main);
            edtNumber = findViewById(R.id.edtNumber);
            btnSatu = findViewById(R.id.btnSatu);
            btnDua = findViewById(R.id.btnDua);
            btnTiga = findViewById(R.id.btnTiga);
            btnEmpat = findViewById(R.id.btnEmpat);
            btnLima = findViewById(R.id.btnLima);
            btnEnam = findViewById(R.id.btnEnam);
            btnTujuh = findViewById(R.id.btnTujuh);
            btnDelapan = findViewById(R.id.btnDelapan);
            btnSembilan = findViewById(R.id.btnSembilan);
            btnNol = findViewById(R.id.btnNol);
            btnPlus = findViewById(R.id.btnPlus);
            btnMinus = findViewById(R.id.btnMinus);
            btnDiv = findViewById(R.id.btnDiv);
            btnTimes = findViewById(R.id.btnTimes);
            btnEqual = findViewById(R.id.btnEqual);
            Button btnReset;
            btnReset = findViewById(R.id.btnRes);

            String number_temp =" ";



            btnSatu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("1");
                }

            });

            btnDua.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("2");;//Shift+" == Autocomplete
                }
            });

            btnTiga.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("3");
                }
            });
            btnEmpat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("4");
                }
            });
            btnLima.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("5");
                }
            });
            btnEnam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("6");
                }
            });
            btnTujuh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("7");
                }
            });
            btnDelapan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("8");
                }
            });
            btnSembilan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("9");
                }
            });
            btnNol.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("0");
                }
            });
            btnPlus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("+");
                }
            });
            btnDiv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("/");
                }
            });
            btnMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("-");
                }
            });
            btnTimes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    edtNumber.append("*");
                }
            });



            btnEqual.setOnClickListener(new View.OnClickListener() {
          @Override
            public void onClick(View view) {
              String operation = edtNumber.getText().toString();
              String[] numerator = operation.split("(?<=[-+*/])|(?=[-+*/])");
              double operationOutput = 0;
              char lastoperand = '+';
              try {
                  for (String partial : numerator) {
                      partial = partial.trim();
                      if (partial.isEmpty()) {
                          continue;
                      }
                      if (partial.matches("[+*/-]")) {
                          lastoperand = partial.charAt(0);
                      } else {
                          double numerat = Double.parseDouble(partial);
                          switch (lastoperand) {
                              case '+':
                                  operationOutput += numerat;
                                  break;
                              case '-':
                                  operationOutput -= numerat;
                                  break;
                              case '*':
                                  operationOutput *= numerat;
                                  break;
                              case '/':
                                  if (numerat != 0) {
                                      operationOutput /= numerat;

                                  } else {
                                    edtNumber.setText("can't divide by 0");
                                    return;
                                  }
                                  break;
                              default:
                                  operationOutput = numerat;
                          }
                      }
                  }
                  edtNumber.setText(String.valueOf(operationOutput));

              } catch (Exception e) {
                  edtNumber.setText("error");
              }
          }
          });

btnReset.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        edtNumber.setText("");
    }
});
     ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
        }