#include <stdio.h>
#include <string.h>

struct data{
    char Location_1[100],Location_2[100],Furnish[100],type[100],CarParks[100];
    char Rooms[100],Bathrooms[100];
    int price,area;
}info[10000];

int main() {
  
    char search_criteria[100], column_name[100];
    printf ("Column name\n");
    printf ("1. Location_1\n");
	printf ("2. Location_2\n");
	printf ("3. Rooms\n");
	printf ("4. Bathrooms\n");
	printf ("5. CarParks\n");
	printf ("6. type\n");
	printf ("7. Furnish\n");
    printf("Enter search criteria (DataX in Column_name): ");
    scanf("%s in %s", &search_criteria,column_name);

 
    FILE *fp = fopen("file.csv", "r");
    int b = 0;
    int r = 0;
    char header[1000];
    fgets(header, 1000, fp);
   while (fscanf(fp, "%[^,],%[^,],%d,%[^,],%[^,],%[^,],%[^,],%d,%[^\n]\n", info[b].Location_1, info[b].Location_2, &info[b].price, info[b].Rooms, info[b].Bathrooms, info[b].CarParks, info[b].type, &info[b].area, info[b].Furnish) != EOF) {
        b++;
        r++;
}

        if(strcmp(column_name, "Location_1") == 0){
        for(int i = 0 ; i < r ; i++){
            if (strstr(info[i].Location_1, search_criteria) != NULL) {
                printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
            }
        }
    }
    
    
    else if(strcmp(column_name, "Location_2") == 0){
        for(int i = 0 ; i < r ; i++){
            if (strstr(info[i].Location_2, search_criteria) != NULL) {
                printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
            }
        }
    }
   
    else if(strcmp(column_name, "Furnish") == 0){
        for(int i = 0 ; i < r ; i++){
            if (strstr(info[i].Furnish, search_criteria) != NULL) {
                printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
            }
        }
    }
    
    else if(strcmp(column_name, "type") == 0){
        for(int i = 0 ; i < r ; i++){
            if (strstr(info[i].type, search_criteria) != NULL) {
                printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
            }
        }
    }
    else if((strcmp(column_name, "CarParks") == 0)) {
    	for (int i=0;i<r;i++){
    		if (strstr(info[i].CarParks,search_criteria)!=NULL){
    			  printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
			}
		}
            }
             else if((strcmp(column_name, "Rooms") == 0)) {
    	for (int i=0;i<r;i++){
    		if (strstr(info[i].Rooms,search_criteria)!=NULL){
    			  printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
			}
		}
            }
             else if((strcmp(column_name, "Bathrooms") == 0)) {
    	for (int i=0;i<r;i++){
    		if (strstr(info[i].Bathrooms,search_criteria)!=NULL){
    			  printf("%-20s| %-15s| %-8d| %-3s| %-3s| %-3s| %-10s| %-5d| %s\n", 
                info[i].Location_1, info[i].Location_2, info[i].price, info[i].Rooms, info[i].Bathrooms,
                info[i].CarParks, info[i].type, info[i].area, info[i].Furnish);
			}
		}
            }
             else {
        printf("Invalid column name entered");
    }
    fclose(fp);
    return 0;
        }
    
        

   
   

   

