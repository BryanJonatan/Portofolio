#include <stdio.h>
#include <string.h>


struct data{
	char Location_1[100],Location_2[100],Furnish[100],Rooms[100],Bathrooms[100],CarParks[100],type[100];
	long long int price,area;
};

int findIndex(char* location, char arrlocation[][100], int count) {
    for (int i = 0; i < count; i++) {
        if (strcmp(location, arrlocation[i]) == 0) {
            return i;
        }
    }
    return -1;
}
int main (){
	int input;
	printf ("1. Location 1\n");
	printf ("2. Location 2\n");
	printf ("3. Price\n");
	printf ("4. Rooms\n");
	printf ("5. Bathrooms\n");
	printf ("6. CarParks\n");
	printf ("7. Type\n");
	printf ("8. Area\n");
	printf ("9. Furnish\n");
	printf ("choose: ");
	scanf ("%d",&input);
	
    
	FILE *fpnagara = fopen("file.csv","r");
	if (fpnagara == NULL){
		printf ("Cannot read file\n");
		return 1;
	} 
	
	if (input == 1){
   char header[1000];
    fgets(header, 1000, fpnagara);
    struct data info;
    char location1[100][100] = {{0}};
    int location1_count[100] = {0};
    int count = 0;
    
    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        if (strcmp(info.Location_1, "Location_1") != 0) {
            int index = findIndex(info.Location_1, location1, count);
            if(index == -1) {
                strcpy(location1[count], info.Location_1);
                location1_count[count] = 1;
                count++;
            } else {
                location1_count[index]++;
            }
        }
    }
    
    for (int i=0;i<count;i++) {
        printf("%s : %d\n", location1[i], location1_count[i]);	
		}
				
		int min_frequency = location1_count[0];
		int max_frequency = location1_count[0];
		for (int i=1; i<count;i++) {
		if (location1_count[i] < min_frequency) {
        min_frequency = location1_count[i];
		 }
		 else if (location1_count[i]>max_frequency) {
        max_frequency = location1_count[i];
		}
}
       int min_location, max_location;
         for (int i=0;i<count;i++) {
	   if (location1_count[i] == max_frequency) {
        max_location = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n",location1[max_location],max_frequency);
		
	   for (int i=0;i<count;i++) {
	   if (location1_count[i] == min_frequency) {
	   min_location = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n",location1[min_location],min_frequency);
    }



    else if (input==2){
    	 char header[1000];
    fgets(header, 1000, fpnagara);
    struct data info;
    char location2[100][100] = {{0}};
    int location2_count[100] = {0};
    int count = 0;

    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        int index = findIndex(info.Location_2, location2, count);
        if (index == -1) {
            strcpy(location2[count], info.Location_2);
            location2_count[count] = 1;
            count++;
        } else {
            location2_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", location2[i], location2_count[i]);    
	}
	
		int min_frequency = location2_count[0];
		int max_frequency = location2_count[0];
		for (int i = 1; i < count; i++) {
		if (location2_count[i] < min_frequency) {
        min_frequency = location2_count[i];
		 }
		 else if (location2_count[i] > max_frequency) {
        max_frequency = location2_count[i];
		}
}

       int min_location, max_location;
         for (int i = 0; i < count; i++) {
	   if (location2_count[i] == max_frequency) {
        max_location = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", location2[max_location], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (location2_count[i] == min_frequency) {
	   min_location = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", location2[min_location], min_frequency);
    }

else if (input == 3){
	char header[1000];
    fgets(header, 1000, fpnagara);
	struct data info;
    int count = 0;
	long long int min_price = -1, max_price = -1, total_price = 0;
	int count_price = 0;

while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%d,%[^\n]\n"
, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
    if (strcmp(info.Location_1, "Location_1") != 0) {
        if (min_price == -1 || info.price < min_price) {
            min_price = info.price;
        }
        else if (max_price == -1 || info.price > max_price) {
            max_price = info.price;
        }
        total_price += info.price;
        count_price++;
    }
}

printf("Minimum price: %lld\n", min_price);
printf("Maximum price: %lld\n", max_price);
if(count_price > 0)
    printf("Average price: %lld\n", total_price / count_price);
else
    printf("No data found for the price column\n");
}

else if (input==4){
	 char header[1000];
    fgets(header, 1000, fpnagara);
	   struct data info;
    char rooms[100][100] = {{0}};
    int rooms_count[100] = {0};
    int count = 0;
    
    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        int index = findIndex(info.Rooms, rooms, count);
        if (index == -1) {
            strcpy(rooms[count], info.Rooms);
            rooms_count[count] = 1;
            count++;
        } else {
            rooms_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", rooms[i], rooms_count[i]);
    }
    
    	int min_frequency = rooms_count[0];
		int max_frequency = rooms_count[0];
		for (int i = 1; i < count; i++) {
		if (rooms_count[i] < min_frequency) {
        min_frequency = rooms_count[i];
		 }
		 else if (rooms_count[i] > max_frequency) {
        max_frequency = rooms_count[i];
		}
}

       int min_rooms, max_rooms;
         for (int i = 0; i < count; i++) {
	   if (rooms_count[i] == max_frequency) {
        max_rooms = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", rooms[max_rooms], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (rooms_count[i] == min_frequency) {
	   min_rooms = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", rooms[min_rooms], min_frequency);
}

else if (input==5){
	char header[1000];
    fgets(header, 1000, fpnagara);
	struct data info;
    char bathrooms[100][100] = {{0}};
    int bathrooms_count[100] = {0};
    int count = 0;
    
    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        int index = findIndex(info.Bathrooms, bathrooms, count);
        if (index == -1) {
            strcpy(bathrooms[count], info.Bathrooms);
            bathrooms_count[count] = 1;
            count++;
        } else {
            bathrooms_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", bathrooms[i], bathrooms_count[i]);
    }
    
    int min_frequency = bathrooms_count[0];
		int max_frequency = bathrooms_count[0];
		for (int i = 1; i < count; i++) {
		if (bathrooms_count[i] < min_frequency) {
        min_frequency = bathrooms_count[i];
		 }
		 else if (bathrooms_count[i] > max_frequency) {
        max_frequency = bathrooms_count[i];
		}
}

       int min_bathrooms, max_bathrooms;
        for (int i = 0; i < count; i++) {
	   if (bathrooms_count[i] == max_frequency) {
        max_bathrooms = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", bathrooms[max_bathrooms], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (bathrooms_count[i] == min_frequency) {
	   min_bathrooms = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", bathrooms[min_bathrooms], min_frequency);
}

else if (input==6){
	char header[1000];
    fgets(header, 1000, fpnagara);
	struct data info;
    char CarParks[100][100] = {{0}};
    int CarParks_count[100] = {0};
    int count = 0;
    
    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        int index = findIndex(info.CarParks, CarParks, count);
        if (index == -1) {
            strcpy(CarParks[count], info.CarParks);
            CarParks_count[count] = 1;
            count++;
        } else {
            CarParks_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", CarParks[i], CarParks_count[i]);
    }
    
    int min_frequency = CarParks_count[0];
		int max_frequency = CarParks_count[0];
		for (int i = 1; i < count; i++) {
		if (CarParks_count[i] < min_frequency) {
        min_frequency = CarParks_count[i];
		 }
		 else if (CarParks_count[i] > max_frequency) {
        max_frequency = CarParks_count[i];
		}
}

       int min_CarParks, max_CarParks;
        for (int i = 0; i < count; i++) {
	   if (CarParks_count[i] == max_frequency) {
        max_CarParks = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", CarParks[max_CarParks], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (CarParks_count[i] == min_frequency) {
	   min_CarParks = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", CarParks[min_CarParks], min_frequency);
}

else if (input==7){
	char header[1000];
    fgets(header, 1000, fpnagara);
		   struct data info;
    char type[100][100] = {{0}};
    int type_count[100] = {0};
    int count = 0;
  
    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        int index = findIndex(info.type, type, count);
        if (index == -1) {
            strcpy(type[count], info.type);
            type_count[count] = 1;
            count++;
        } else {
            type_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", type[i], type_count[i]);
		}
		
		int min_frequency = type_count[0];
		int max_frequency = type_count[0];
		for (int i = 1; i < count; i++) {
		if (type_count[i] < min_frequency) {
        min_frequency = type_count[i];
		 }
		 else if (type_count[i] > max_frequency) {
        max_frequency = type_count[i];
		}
}

       int min_type, max_type;
        for (int i = 0; i < count; i++) {
	   if (type_count[i] == max_frequency) {
        max_type = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", type[max_type], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (type_count[i] == min_frequency) {
	   min_type = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", type[min_type], min_frequency);
    }


else if (input ==8){
		char header[1000];
    fgets(header, 1000, fpnagara);
	  struct data info;
    int count = 0;
	long long int min_area = -1, max_area = -1, total_area = 0;
	int count_area = 0;
	while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF){
   
    if (strcmp(info.Location_1, "Location_1") != 0) {
        if (min_area == -1 || info.area < min_area) {
            min_area = info.area;
        }
        if (max_area == -1 || info.area > max_area) {
            max_area = info.area;
        }
        total_area += info.area;
        count_area++;
    }
}

printf("Minimum area: %lld\n", min_area);
printf("Maximum area: %lld\n", max_area);
if(count_area > 0)
    printf("Average area: %lld\n", total_area / count_area);
else
    printf("No data found for the price column\n");
}

else if (input==9){
	char header[1000];
    fgets(header, 1000, fpnagara);
	struct data info;
    char furnish[100][100] = {{0}};
    int furnish_count[100] = {0};
    int count = 0;

    while (fscanf(fpnagara, "%[^,],%[^,],%lld,%[^,],%[^,],%[^,],%[^,],%lld,%[^\n]\n"
	, info.Location_1, info.Location_2, &info.price, info.Rooms, info.Bathrooms, info.CarParks, info.type, &info.area, info.Furnish) != EOF) {
        
		int index = findIndex(info.Furnish, furnish, count);
        if (index == -1) {
            strcpy(furnish[count], info.Furnish);
            furnish_count[count] = 1;
            count++;
        } else {
            furnish_count[index]++;
        }
    }

    for (int i = 0; i < count; i++) {
        printf("%s: %d\n", furnish[i], furnish_count[i]);
    }
    
    	int min_frequency = furnish_count[0];
		int max_frequency = furnish_count[0];
		for (int i = 1; i < count; i++) {
		if (furnish_count[i] < min_frequency) {
        min_frequency = furnish_count[i];
		 }
		 else if (furnish_count[i] > max_frequency) {
        max_frequency = furnish_count[i];
		}
}

       int min_furnish, max_furnish;
        for (int i = 0; i < count; i++) {
	   if (furnish_count[i] == max_frequency) {
        max_furnish = i;
        break;
		}
	}
		printf("Maximum frequency : %s : %d\n", furnish[max_furnish], max_frequency);
		
	   for (int i = 0; i < count; i++) {
	   if (furnish_count[i] == min_frequency) {
	   min_furnish = i;
	   break;
	   }
	}
	   printf("Minimum frequency : %s : %d\n", furnish[min_furnish], min_frequency);
}

else {
	printf ("Invalid number, enter number 1-9\n");
	return 1;
}
fclose(fpnagara);
return 0;
}

