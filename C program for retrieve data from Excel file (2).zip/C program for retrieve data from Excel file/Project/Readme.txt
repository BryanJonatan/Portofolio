This Project is initially created as a Project task for college
which can be saw through the Word file that it is a college Project report

the search function is working by choosing the data we want based on the criteria we want and will be outputting the data

meanwhile describe function will count how many times a Word is being used in the file, where the Word that being count is bades on the data that we want to know such as if we choose location 1, the function will output the count of location that being used in location 1

meanwhile sorting data is an automated function that will sort the Excel data alphabetically