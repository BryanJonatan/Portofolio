#include <stdio.h>
#include <string.h>
struct data{
	char Location_1[100],Location_2[100],Furnish[100],Rooms[100],Bathrooms[100],CarParks[100],type[100];
    int price,area;
}info[10000];

int main (){
	FILE *fp = fopen ("file.csv","r");
	int b=0;
	int r=0;
	char header [1000];
	fgets (header,1000,fp);
	while (fscanf(fp,"%[^,],%[^,],%d,%[^,],%[^,],%[^,],%[^,],%d,%[^\n]\n",info[b].Location_1,info[b].Location_2,&info[b].price
	,info[b].Rooms,info[b].Bathrooms,info[b].CarParks,info[b].type,&info[b].area,info[b].Furnish)!=EOF){
		b++;
		r++;
	}

	
	int i,j;
	struct data temporary;
	for ( i=0;i<r-1;i++){
		for ( j=0;j<r-i-1;j++){
			if (strcmp(info[j].Location_1,info[j+1].Location_1)>0){
				temporary = info[j];
				info[j]=info[j+1];
				info[j+1]=temporary;
			}
		}
	}
	
	for (int b=0;b<r;b++){
		printf ("%-25s| %-25s| %-5d| %-3s| %-3s| %-3s| %-10s| %-8d| %s\n",info[b].Location_1,info[b].Location_2,info[b].price,info[b].Rooms,info[b].Bathrooms,info[b].CarParks,info[b].type,info[b].area,info[b].Furnish);
	}
	fclose(fp);
	return 0 ;
}
