function validate(){
var Name = document.getElementById("Name").value
var Email = document.getElementById("Email").value
var Phone = document.getElementById("Phone").value
var Country = document.getElementById("Country").value
var checkbox = document.getElementById("checkbox").checked

if(Name ==""){
    alert("Name cannot be empty")
}
else if(!Email.endsWith("@gmail.com")){
    alert("Email must ended with @gmail.com")
}
else if(Phone==""){
    alert("Must fill phone number")
}
else if(Phone.charAt(0)!=0){
    alert("Phone number must start with 0")
}
else if(Country=="Empty"){
    alert("Country must be filled")
}
else if(!checkbox){
    alert("Must agree with terms and agreement")
}
else{
    alert("Your Subscription is accepted")
}

}