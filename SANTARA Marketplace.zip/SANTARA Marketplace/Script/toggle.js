﻿const toggle = () => profileDropDownList.classList.toggle('active');
